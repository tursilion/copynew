20000724

Copies a file to another file, but appends an incrementing number starting from 00000.

It was useful once. Windows exe included, but will probably build elsewhere with minimal effort.
